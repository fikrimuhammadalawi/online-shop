<?php
session_start();
$koneksi = new mysqli("localhost","root","","toko_parfume");


//jk tidak ada session pembeli(blm login,). mk dilarikan ke login.php
if (!isset($_SESSION["pembeli"]))
{
    echo "<script>alert('silahkan login');</script>";
    echo "<script>location='login.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <tittle>checkout</tittle>
    <link rel="stylesheet" href="admin/assets/css/boostrap.css">
</head>
<body>
    <!-- navbar -->
    <!-- navbar -->
<!-- navbar -->
<nav class="navbar navbar-default">
    <div class="container">

        <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="keranjang.php">Keranjang</a></li>
            <!-- jk sudah login(ada session pembeli) -->
            <?php if (isset($_SESSION["pembeli"])): ?>
                <li><a href="logout.php">Logout</a></li>
            <!-- sealin itu(blm login) (blm ada session pembeli) -->
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif ?>
            
            <li><a href="checkout.php">Checkout</a></li>
        </ul>
    </div>
</nav>

<section class="konten">
	<div class="container">
		<h1>Keranjang Belanja</h1>
		<hr>
		<table class="table table-bordered ">
			<thead>
			<tr>
				<th>No</th>
				<th>Produk</th>
				<th>Harga</th>
				<th>Jumlah</th>
				<th>Subharga</th>
			</tr>
			</thead>
			<tbody>
			<?php $nomor=1; ?>
			<?php foreach ($_SESSION["keranjang"] as $id_parfum=> $jumlah):?>
			<!-- menampilkan produk yang sedang diperulangkan berdasarkan id_produk -->
			<?php 
			$ambil = $koneksi->query("SELECT * FROM parfum
			WHERE id_parfum='$id_parfum'");
			$pecah = $ambil->fetch_assoc();
			$subharga = $pecah["harga"]*$jumlah;
			?>
				<tr>
					<td><?php echo $nomor; ?></td>
					<td><?php echo $pecah["nama_parfum"]; ?></td>
					<td>Rp. <?php echo number_format($pecah["harga"]); ?></td>
					<td><?php echo $jumlah; ?></td>
					<td>Rp. <?php echo number_format($subharga); ?></td>]
				</tr>
				<?php $nomor++; ?>
				<?php endforeach ?>
			</tbody>
		</table>
\
        <form method="post">
                <div class="form-group">
                    <input type="text">
                </div>
        </form>
	</div>
</section>

<pre>
    <?php print_r($_SESSION["pembeli"]); ?>
</pre>

</body>