<?php
session_start();
$koneksi = new mysqli("localhost","root","","toko_parfume");
   $email = $_POST['email'];
   $password = $_POST['password'];
   $nama = $_POST['nama'];
   $alamat = $_POST['alamat'];
   $tanggal = $_POST['tanggal'];
   $sql = "SELECT * FROM pembeli WHERE email_customer = '$email'";
   $query = $koneksi->query($sql);
   if($query->num_rows != 0) {
     echo "<div align='center'><h1>Username Sudah Terdaftar! <a href='daftar.php'>Back?</a></div>";
   } else {
     if(!$email || !$password ||!$nama ||!$alamat ||!$tanggal ) {
       echo "<div align='center'><h1>Masih ada data yang kosong!</h1> <a href='daftar.php'>Back?</a>";
     } else {
       $data = "INSERT INTO pembeli VALUES ('$email', '$password', '$nama', '$tanggal','$alamat')";
       $simpan = $koneksi->query($data);
       if($simpan) {
         echo "<div align='center'><h1>Pendaftaran Sukses, Silahkan <a href='login.php'>Login</h1></a></div>";
       } else {
         echo "<div align='center'><h1>Proses Gagal!</h1></div>";
       }
     }
   }
?>