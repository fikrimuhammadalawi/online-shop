<h2>Ubah Parfum</h2>
<?php
$ambil = $koneksi->query("SELECT * FROM parfum WHERE id_parfum='$_GET[id]'");
$pecah= $ambil->fetch_assoc();

echo "<pre>";
print_r($pecah);
echo "</pre>";
?>

<form method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>Nama Parfum</label>
        <input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama_parfum']; ?>">
    </div>
    <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" class="form-control" name="harga" value="<?php echo $pecah['harga']; ?>">
    </div>
    <div class="form-group">
        <img src="../foto_parfum/<?php echo $pecah['gambar_parfum'] ?>" width="200">
    </div>
    <div class="form-group">
        <label>Ganti Foto</label>
        <input type="file" name="foto" class="form-control">
    </div>
    <div class="form-group">
        <label>Deskripsi</label>
        <textarea name="deskripsi" class="form-control" rows="10"><?php echo $pecah['deskripsi']; ?></textarea>
    </div>
    <button class="btn btn-primary" name="ubah">Ubah</button>   
</form>

<?php
if (isset($_POST['ubah']))
{
    $namafoto=$_FILES['foto']['name'];
    $lokasifoto = $_FILES['foto']['name'];
    // jk foto dirubah
    if (!empty($lokasifoto))
    {
        move_uploaded_file($lokasifoto, "../foto_parfum/$namafoto");

        $koneksi->query("UPDATE parfum SET nama_parfum=$_POST[nama]',
            harga='$_POST[harga]',deskripsi='$_POST[deskripsi]',
            gambar_parfum='$_POST[foto]',stok='$_POST[stok]' 
            WHERE id_parfum='$_GET[id]'");
    }
    else
    {
        $koneksi->query("UPDATE parfum SET nama_parfum=$_POST[nama]',
            harga='$_POST[harga]',deskripsi='$_POST[deskripsi]',
            gambar_parfum='$_POST[foto]',stok='$_POST[stok]' WHERE id_parfum='$_GET[id]'");
    }
    echo "<script>aleart('data produk telah diubah');</script>";
    echo "<script>location='index.php?halaman=produk';</script>";
}
?>