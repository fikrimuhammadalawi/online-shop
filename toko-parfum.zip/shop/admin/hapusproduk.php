<?php

$ambil = $koneksi->query("SELECT * FROM parfum WHERE id_parfum= '$_GET[id]'");
$pecah = $ambil->fetch_assoc();
$fotoproduk = $pecah['gambar_parfum'];
if (file_exists("../foto_produk/$fotoproduk")) 
{
    unlink("../foto_produk/$fotoproduk");
}


$koneksi->query("DELETE FROM parfum WHERE id_parfum='$_GET[id]'");

echo "<script>alert('produk terhapus')</script>";
echo "<script>location='index.php?halaman=produk'</script>";

?>